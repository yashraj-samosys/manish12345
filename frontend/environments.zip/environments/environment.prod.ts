export const environment = {
  production: true,
  apiURL: 'http://172.105.20.144:3000/',
  MapUrl: 'http://103.15.67.78:4001/?fsa=&userid=&loginid=',
  apiKey: "AIzaSyCw5HU78Jk6AzpPCkrwJdEj8a_7LeAUS8I",
  PaymentUrl: "http://172.105.20.144:3000/makePayment/paymentpage/",
  image_path: "http://172.105.20.144:3000/images/"
};
